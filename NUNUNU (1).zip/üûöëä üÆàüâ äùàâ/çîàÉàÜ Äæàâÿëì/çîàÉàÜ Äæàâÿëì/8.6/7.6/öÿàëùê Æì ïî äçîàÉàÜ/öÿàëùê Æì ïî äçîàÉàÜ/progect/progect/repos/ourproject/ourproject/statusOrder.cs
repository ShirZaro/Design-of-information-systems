﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ourproject
{
    public enum statusOrder
    {
        open_order,
        order_ready_to_pay,
        order_paid,
        making_order,
        order_in_distribution,
        order_late,
        order_cenceled,
        order_complited,
        order_complaind

    }
}
