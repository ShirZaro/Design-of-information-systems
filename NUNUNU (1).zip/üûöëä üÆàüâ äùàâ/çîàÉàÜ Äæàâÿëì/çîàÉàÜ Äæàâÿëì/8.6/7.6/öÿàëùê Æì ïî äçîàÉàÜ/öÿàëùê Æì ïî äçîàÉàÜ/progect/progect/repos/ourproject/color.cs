﻿using System;

namespace ourproject
{
    public enum color
    {
        blue,
        red,
        pink,
        green,
        purple,
        black

    }

}
