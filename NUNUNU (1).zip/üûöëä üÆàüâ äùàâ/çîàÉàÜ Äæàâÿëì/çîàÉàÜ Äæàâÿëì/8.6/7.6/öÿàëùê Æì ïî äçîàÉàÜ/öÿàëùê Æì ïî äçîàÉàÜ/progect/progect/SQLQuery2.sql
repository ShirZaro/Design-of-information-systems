alter table buyers add column [finnance Directors ID] int null

alter table compensationComplaint add CONSTRAINT fk_compensation11 FOREIGN KEY (customerServiceClerckID) REFERENCES customer_service_clerks(id)

alter table compensationComplaint add   statusDirector status   null

REFERENCES finnanceDirectors

insert into CompensationComplaint values('47845','the curier destroyed my package',' Transferred to the manager','destroyed', 4, 20857974,23,'Treated')