﻿using System;
namespace ourproject
{

    public enum status
    {
        In_treatment,
        Not_treated,
        Treated,
        Transferred_to_the_manager

    }
}
