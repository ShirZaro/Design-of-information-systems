﻿using System;
namespace ourproject
{
    public class product
    {
        private string barcode;
        private bool valid_in_stock;
        private int units_in_stock;
        private category category; 
        private
        private







        public product()
        {

        }
    }
}
