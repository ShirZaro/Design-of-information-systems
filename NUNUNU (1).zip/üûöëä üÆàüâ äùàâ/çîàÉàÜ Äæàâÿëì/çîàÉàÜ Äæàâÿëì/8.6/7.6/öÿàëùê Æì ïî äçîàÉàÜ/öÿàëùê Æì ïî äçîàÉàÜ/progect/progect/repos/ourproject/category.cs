﻿using System;

namespace ourproject
{

    public enum category
    {
        buttonShirt,
        pants,
        shirts,
        shoes,
        dresses,
        skirts
    }

}
