﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ourproject
{
    public enum category
    {
        buttonShirt,
        pants,
        shirts,
        shoes,
        dresses,
        skirts
    }
}
