﻿using System;

namespace ourproject
{
    public enum fabric
    {
        Corduroy,
        Silk,
        Cotton,
        Stan,
        Flannal,
        Lattise,
        Muslin

    }
}
