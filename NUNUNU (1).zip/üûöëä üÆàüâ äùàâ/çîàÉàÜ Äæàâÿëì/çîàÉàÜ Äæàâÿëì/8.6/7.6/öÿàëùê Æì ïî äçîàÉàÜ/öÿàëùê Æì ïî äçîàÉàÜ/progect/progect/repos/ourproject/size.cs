﻿using System;

namespace ourproject

{
    public enum size
    {
        s,
        m,
        l,
        xl
    }


}
