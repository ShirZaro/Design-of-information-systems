Create Procedure dbo.buyers
AS
Select*from dbo.buyers

Create Procedure dbo.Customers
AS
Select*from dbo.Customers

Create Procedure dbo.complaints
AS
Select*from dbo.complaints

Create Procedure dbo.workers
AS
Select*
from  customer_servise_clerk  join customer_service_directors  join financedirectors  join operation_directors 
join 


Create Procedure dbo.discounts
AS
Select*from dbo.discounts


Create Procedure get_all_product_orders
AS
Select*from dbo.Products_Orders

CREATE PROCEDURE dbo.customer_service_clerks @id int, @name varchar(50), @Exprience int,@birthdate date , @email varchar(50) ,@rate real 
AS
INSERT INTO dbo.customer_service_clerks
Values (@id , @name , @Exprience,@birthdate , @email ,@rate )


CREATE PROCEDURE dbo.SP_Update_worker @id int, @name varchar(50), @Exprience int,@birthdate date , @email varchar(50) ,@rate real 
AS
Update dbo.Workers
SET
workerName=@name, workerTitle=@title
WHERE workerId=@id


CREATE PROCEDURE dbo.SP_delete_worker @id integer
AS
Delete from  dbo.Workers
WHERE workerId=@id